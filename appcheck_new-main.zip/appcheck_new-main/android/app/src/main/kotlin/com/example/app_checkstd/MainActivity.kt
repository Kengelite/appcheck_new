package com.example.app_checkstd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
